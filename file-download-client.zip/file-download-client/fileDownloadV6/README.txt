Run servers:
node run.js


Then run client:
node download.js

will download fav.mp3 to local.

diff fav.mp3 fav-local.mp3 will check the file download if it is completed.
