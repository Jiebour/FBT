var RES_INFO_PATH = 'nedb_data\\res_info';
var RES_HASH_PATH = 'nedb_data\\res_hash';
var seed = 0xAAAA;

exports.RES_INFO_PATH = RES_INFO_PATH;
exports.RES_HASH_PATH = RES_HASH_PATH;
exports.seed = seed;