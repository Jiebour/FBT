def hello():
    print("this is file 2!")